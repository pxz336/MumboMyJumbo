<?php include ("sessions.php");
include "dbConnect.php";

if (isset($_SESSION['userName'])) {
    echo "<input type = 'hidden' id = 'userNameSession' name = 'userNameSession'
              value = '" . $_SESSION['userName'] . "'>";
}

if (isset($_GET['artID'])) {
    $article = $_GET['artID'];
    echo "<input type = 'hidden' id = 'artID' name = 'artID' value = '" . $article . "'>";
    dbConnect();
    $clean_art_id = mysqli_real_escape_string($connect, $article);
    
    $get_art_sql = "select * from post where post_id = '" . $clean_art_id . "'";
    $get_art_res = mysqli_query($connect, $get_art_sql)
        or die (mysqli_error($connect) . "Error getting article");
    
    if (mysqli_num_rows($get_art_res) != 1) {
        header("Location: homepage.php");
    } else {
        $get_art_data = mysqli_fetch_array($get_art_res, MYSQLI_ASSOC);
        
        mysqli_query($connect, "update post set num_views = num_views+1 where post_id = " 
            . $clean_art_id);
        
        $get_photo_sql = "select filepath from post_images where post_id = '" . $clean_art_id . "'";
        $get_photo_res = mysqli_query($connect, $get_photo_sql)
            or die (mysqli_error($connect) . "Error getting article");
        $get_photo_data = mysqli_fetch_array($get_photo_res, MYSQLI_ASSOC);
    }
    
} else {
    header("Location: homepage.php"); 
}

?>

<!DOCTYPE html>
<html>
    <head>  
        
        <?php include ("header.php")?>
                
        <script> 
            /*$(document).ready(function(){
                alterLoginButtons(); 
                
                //$("#art-photo").src = $("#");//oop
                $("#art-title").text($("#artTitle").val());
                $("#art-text").text($("#artText").val());
                
                //$("#stats").text(("#artTitle").text());
                
                
                //If you're logged in, hides some buttons
                //alterLoginButtons();                                
            });*/
        </script>        
        
        
        <title><?php $get_art_data['post_title']?></title>
    </head>
    
    <body>
        <?php include("nav.php")?>        
        
        <div class = "container-fluid" id = "art-content" name = "art-content">
            <img class = "art-specialfit" src = "<?php echo ($get_photo_data['filepath'])?>" id = "art-photo">
            <div id = "stats" style = "color: gray; text-align: center">
                <?php 
                    echo ("Likes: " . $get_art_data['num_likes']);
                    echo (" Dislikes: " . $get_art_data['num_dislikes']);
                    echo (" Views: " . $get_art_data['num_views']);
                ?>
            </div>
            <h1 class = "container-fluid" id = "art-title" style = "text-align: center; max-width: 38ch; margin: auto;"><?php echo ($get_art_data['post_title'])?></h1>
            
            <div class = "container-fluid" id = "art-text" style = "max-width: 65ch; margin: auto;"><?php echo ($get_art_data['post_text'])?></div>        
        </div>        
        
        <?php include("footer.php")?>        
    </body>
</html>