<?php include ("sessions.php");

//If no user logged in
if (!isset($_SESSION['userName'])){
    header("Location: loginForm.html");
}

//type = 'hidden'
if (isset($_SESSION['title'])) {//Saves title if error w/ photo upload
    echo "<input type = 'hidden' id = 'savedTitle' name = 'savedTitle'
        value = '" . $_SESSION['title'] . "'>";
}

if (isset($_SESSION['article'])) { //Saves article if error w/ photo upload
    echo "<input type = 'hidden' id = 'savedArticle' name = 'savedArticle'
                  value = '" . $_SESSION['article'] . "'>";
}

if (isset($_SESSION['imgErr'])) { //Displays photo error msg if there is one
    echo "<input type = 'hidden' id = 'imgErrMsg' name = 'imgErrMsg'
                  value = '" . $_SESSION['imgErr'] . "'>";
}

if (isset($_SESSION['exten'])) {
    echo $_SESSION['exten'];
}

?>


<!DOCTYPE html>
<html>
    <head>        
        <?php include ("header.php")?>        
        
        <!--If error posting, replaces inputs and gives error message-->
        <script>
            $(document).ready(function(){                
                if ($("#savedTitle")) {
                    $("#artTitle").val($("#savedTitle").val());
                }
                
                if ($("#savedArticle")) {
                    $("#artText").val($("#savedArticle").val());
                }       
                                  
                if ($("#imgErrMsg")) {
                    $("#errMsg").show();
                    $("#errMsg").html($("#imgErrMsg").val());
                } else {
                    $("#errMsg").hide();
                }                
            });        
        </script>
        
        
        <title>Make a new Mumbo post!</title>
        
    </head>
    
    <body>
        <?php include ("nav.php")?>  
        <div class = "container-fluid form-center">
            <h1>Add To Our Trash Fire!</h1>
            <form method="post" action="imgUpload.php" enctype="multipart/form-data">
                <div>
                    <label for = "artTitle" style = "text-decoration: underline;">Article Title: </label>
                    <br>
                    <input type="text" id = "artTitle" name = "artTitle" 
                           size = "40" maxlength="65" placeholder = 
                           "Runnin through the six with my woas." required = "required"
                           autofocus = "true">
                    <!--Want to add an onblur which will post info to session-->
                    <br><br>
                    <label for = "img">Select a photo: </label>
                    <input type = "file" id = "img" name = "img" class="btn btn-outline-success my-2 my-sm-0">
                    <br>
                    <label for = "img" style = "color: gray">(JPG, JPEG, PNG, or GIF images under 5MB)</label>
                </div>
                <div id = "errMsg" name = "errMsg" style = "color: red"></div>
                <div>
                    <label for = "artText" style = "text-decoration: underline;">Article Content: </label>
                    <br>
                    <textarea id = "artText" name = "artText" cols = "65" rows = "10"
                              placeholder = "Give us that good good." required = "required"></textarea>
                </div>
                
                <br>
                
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name = "submit" value="submit">New Post!</button>        
            </form>
        </div>
        
        <?php include ("footer.php")?>  
        
    </body>
</html>