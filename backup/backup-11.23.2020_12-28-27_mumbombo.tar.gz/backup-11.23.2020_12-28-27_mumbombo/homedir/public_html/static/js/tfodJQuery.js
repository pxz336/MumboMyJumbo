function loadTFOD(){
    
    $(.attached).click(function(){
        $(.attached).after("<div class = 'color-box attached'>This is appended <b></div>");    
    });
    
}