-- MySQL dump 10.13  Distrib 5.6.41-84.1, for Linux (x86_64)
--
-- Host: localhost    Database: mumbombo_main
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mumbombo_main`
--


--
-- Table structure for table `comment_post_key`
--

DROP TABLE IF EXISTS `comment_post_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_post_key` (
  `comment_id_key` int(11) NOT NULL,
  `post_id_key` int(11) NOT NULL,
  PRIMARY KEY (`comment_id_key`,`post_id_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_post_key`
--

LOCK TABLES `comment_post_key` WRITE;
/*!40000 ALTER TABLE `comment_post_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_post_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `num_likes_comment` int(11) DEFAULT '0',
  `num_dislikes_comment` int(11) DEFAULT '0',
  `date_comment` date NOT NULL,
  `comment_text` text NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friends_list`
--

DROP TABLE IF EXISTS `friends_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends_list` (
  `user_id_key` int(11) NOT NULL,
  `friend_id_key` int(11) NOT NULL,
  PRIMARY KEY (`user_id_key`,`friend_id_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friends_list`
--

LOCK TABLES `friends_list` WRITE;
/*!40000 ALTER TABLE `friends_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `friends_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mumbo_profile`
--

DROP TABLE IF EXISTS `mumbo_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mumbo_profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name_profile` varchar(30) NOT NULL,
  `last_name_profile` varchar(30) NOT NULL,
  `user_name_profile` varchar(30) NOT NULL,
  `create_date_profile` date NOT NULL,
  `profile_photo` text,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mumbo_profile`
--

LOCK TABLES `mumbo_profile` WRITE;
/*!40000 ALTER TABLE `mumbo_profile` DISABLE KEYS */;
INSERT INTO `mumbo_profile` (`profile_id`, `first_name_profile`, `last_name_profile`, `user_name_profile`, `create_date_profile`, `profile_photo`) VALUES (1,'Patrick','Zmina','WoweeWettee','2020-07-09',NULL),(2,'Paete','Zminono','wunderlust','2020-07-09',NULL),(3,'Paete','Zminono','zimbooso','2020-07-09',NULL),(4,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(5,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(6,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(7,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(8,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(9,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(10,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(11,'Zimboo','Zminono','bingo boings','2020-07-09',NULL),(12,'pibble','zibble','my nibble','2020-07-10',NULL),(13,'peteor','metoer','mumbo','2020-07-13',NULL),(14,'bubby','bubberino','penopeno','2020-07-15',NULL),(15,'bumbo','boobie','suckmybungo','2020-07-27',NULL),(16,'Terri','Zmina','mom','2020-08-28',NULL),(17,'Stinky','Marineanimal','Porkus','2020-08-30',NULL),(18,'Tom','Horsfall','TcTuggers22','2020-09-14',NULL),(19,'Pete','Zete','PeteYete22','2020-10-01',NULL),(20,'Tata','Zooba','Donkeh','2020-10-05',NULL),(21,'pog','champ','pog','2020-10-06',NULL),(22,'pa','zm','123','2020-10-07',NULL),(23,'Scott','Woodward','antiquesmuggler','2020-10-07',NULL),(24,'\'','\'','\'','2020-10-07',NULL),(25,'Jonathan','Rodriguez','JonnycomeLately','2020-10-07',NULL),(26,'\' or 1=1\'','\' or 1=1\'','\' or 1=1\'','2020-10-07',NULL),(27,'Patrick','Zmina','Patrick Himself','2020-10-08',NULL),(28,'Calvin','Conklin','Windlenot','2020-10-19',NULL),(29,'Thomas','Horsfall','tom','2020-10-23',NULL);
/*!40000 ALTER TABLE `mumbo_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mumbo_user`
--

DROP TABLE IF EXISTS `mumbo_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mumbo_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(320) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `login_token` varchar(50) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `user_total_likes` int(11) DEFAULT '0',
  `user_total_views` int(11) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mumbo_user`
--

LOCK TABLES `mumbo_user` WRITE;
/*!40000 ALTER TABLE `mumbo_user` DISABLE KEYS */;
INSERT INTO `mumbo_user` (`user_id`, `user_email`, `password`, `login_token`, `first_name`, `last_name`, `user_name`, `create_date`, `user_total_likes`, `user_total_views`) VALUES (1,'themalemonkey@yahoo.com','cheese11','1c5bd3344b03796d09077f5c00a705cec3d6e3ba680846ce','Patrick','Zmina','WoweeWettee','2020-07-09',0,0),(2,'themalemonkey@yahoo.com','hoo hoo',NULL,'Paete','Zminono','wunderlust','2020-07-09',0,0),(3,'the@at.orgy','rew',NULL,'Paete','Zminono','zimbooso','2020-07-09',0,0),(4,'the@at.orgy','rewer',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(5,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(6,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(7,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(8,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(9,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(10,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(11,'the@at.orgy','fes',NULL,'Zimboo','Zminono','bingo boings','2020-07-09',0,0),(12,'giggle@google.oogle','fds','04caa69bcc6b357e5b4587f62493f18bdbf0805f01d462fe','pibble','zibble','my nibble','2020-07-10',0,0),(13,'bumbo@jumbo.org','gfsd','441a89de31af5e2f6dcd62eb43004d590315416f9e385d44','peteor','metoer','mumbo','2020-07-13',0,0),(14,NULL,'rewer',NULL,NULL,NULL,'bingo boings',NULL,0,0),(15,'bubbo@wubbo.og','bingo',NULL,'bubby','bubberino','penopeno','2020-07-15',0,0),(16,'bubbo@gooogle.org','peepo','e84fb46370f81ac3d1737e3cbe3cd39c25572ea3b3cadb97','bumbo','boobie','suckmybungo','2020-07-27',0,0),(17,NULL,NULL,'2a890edc71d3e68145b50c602e6f3bfbf9ec88907ee444ce',NULL,NULL,'22',NULL,0,0),(18,'123@hotmail.com','123abc','0a135e68171be06260d9033cf99538f17f9e6c5fad2ac679','Terri','Zmina','mom','2020-08-28',0,0),(19,'kzmina@gmail.com','donkey','8fa1a8d4be5225a1c79c4c57df1ff8f0fc6d74339e1d96c8','Stinky','Marineanimal','Porkus','2020-08-30',0,0),(20,'2@3.edu','cheese','acf2991c648f24aca1feae1dc0049ce7c45c2c85396273eb','Tom','Horsfall','TcTuggers22','2020-09-14',0,0),(21,'2@3.com','22',NULL,'Pete','Zete','PeteYete22','2020-10-01',0,0),(22,'donkey@youtube.org','cheese','14d80ceeaffd6cb76b0f0cbb8f5e103e28e8470b0c27d7e5','Tata','Zooba','Donkeh','2020-10-05',0,0),(23,'kimbo@jimbo.org','pog','7c1953d6c8e672760f196934522f1b1d69b602132820b546','pog','champ','pog','2020-10-06',0,0),(24,'asdjh@2.co','123','396aa6aa8985f337acba2d484ff36b73fc0516d2fa133452','pa','zm','123','2020-10-07',0,0),(25,'scottandrewfrazier@gmail.com','0813@mumbo','8c955ebc6cd29538b5dcee8817c672421caf8bddbc0c2f6c','Scott','Woodward','antiquesmuggler','2020-10-07',0,0),(26,'lilbinch@tom.com','\'',NULL,'\'','\'','\'','2020-10-07',0,0),(27,'jonrod21@gmail.com','Mumbo@jon#27',NULL,'Jonathan','Rodriguez','JonnycomeLately','2020-10-07',0,0),(28,'lilbinch@tom.coms','\' or 1=1=\'',NULL,'\' or 1=1\'','\' or 1=1\'','\' or 1=1\'','2020-10-07',0,0),(29,'pxz336@gmail.com','Cheese11','428e4b01edcf8f5eb18cbcd0f3678e7072436711944c8677','Patrick','Zmina','Patrick Himself','2020-10-08',0,0),(30,'calvin.conklin.2016@owu.edu','qt5skxF4J2ANyyr',NULL,'Calvin','Conklin','Windlenot','2020-10-19',0,0),(31,'tom@owu.edu','tom','a47164fb13c22cde3128625d66a121cabb9640d562f53ee5','Thomas','Horsfall','tom','2020-10-23',0,0);
/*!40000 ALTER TABLE `mumbo_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `num_likes` int(11) DEFAULT '0',
  `num_dislikes` int(11) DEFAULT '0',
  `num_views` int(11) DEFAULT '0',
  `post_title` varchar(200) NOT NULL,
  `post_text` text NOT NULL,
  `post_date` datetime DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`post_id`, `num_likes`, `num_dislikes`, `num_views`, `post_title`, `post_text`, `post_date`) VALUES (1,0,0,1,'Biggie Smiggie','Smuggle my nards, but don\'t go too too hard?','2020-08-03 00:00:00'),(3,0,0,1,'Want to run out of milk??','You really wanna push me like that? I created you. You can\'t leave milk. THERE. WILL. BE. MILK.','2020-08-04 00:00:00'),(4,0,0,0,'Bubble Guts','Oh lawd I got the bubble guts','2020-08-04 00:00:00'),(5,0,0,0,'Buttery Nuggets Found At Airport','\"What am I supposed to do with all these nuggets?\" Asked Jeremy Manilow, knowing exactly what was needed to be done. All the steps to be taken were right there in front of him, but he refused to take them. And exceptional man? I really do not think so. A responsible man? Maybe. A reprehensible man? That, my friends is unequivocal, and I think we can all learn from these experiences. \"What am I supposed to do with all these nuggets?\" Get real. We all know, we all knew, and to be frank, we all would know in the future. Don\'t be like Gary Manitoba. Don\'t be an it.','2020-08-04 00:00:00'),(6,0,0,0,'Rug Butter, What Is It Good For?','You cannot determine it by yourself, but with a little help from your friends, you can see the light through the darkness. Rub it a little. Tell it a little story. Rug butter will flow forth for your analytical mind to take hold of. I think, in reality, if you use it for the wrong cause, it won\'t matter much. Just make sure that it is truly what you want and where you want it. Rug butter, friend? Or Foe?','2020-08-10 00:00:00'),(7,0,0,0,'rubbibg','bibiob','2020-08-19 00:00:00'),(9,0,0,0,'rgghsdfjksdfghj','ghujghjoghjghjlgjlkgg','2020-08-20 00:00:00'),(15,0,0,0,'pibble','gotta take a nibble','2020-08-20 00:00:00'),(16,0,0,7,'pibble','gotta take a nibble','2020-08-20 00:00:00'),(17,0,0,3,'Bungle it good my frined','You have to you want to you really ought to','2020-08-20 00:00:00'),(18,0,0,8,'boogles','bingos','2020-08-20 00:00:00'),(21,0,0,10,'Saddle Me Up With Sadness','I am a poor poor boy who wishes to be burdened with the sorrows of another man. Call my number! Head me off at the pass! Do what you can to bring it to me, and wring out my cloth of victory. I cannot eject my own sorrow, but I will not reject yours! Saddle me up and watch me unwind, unhinge, and swallow it whole. I am a python for your grief, I am endless, I am encumbered.\r\n\r\nNone of this applies to Bendanits Cumberpunch. Get fuck away.','2020-08-25 15:13:10'),(22,0,0,11,'sunshine','the rain has stopped....yeah!','2020-08-28 15:37:58'),(23,0,0,26,'the cats! I will sniff Bean','\"There is itchy swinging tooties in my eyes!\"\r\n\r\nNO! Zertec doesn\'t help! I dont, know actually. I just want to suffer and itch. I wish i Could tkae my eye ball out and suck on it until it was cleansed with my clean saliva. I hvae good teeth, and genetically superior spit. Please, allow me to trasnfer this good liquid up north.\\\r\n\r\n\r\n\r\nPlease,  can\'t wait to adopt one/ thnka you fro your time. I have a degree in policital science, i promsise.','2020-08-30 22:08:53'),(24,0,0,15,'Top 10 Things To Do With Too Many Tomatoes','1. Ask them how many grapes they can fit in their mouth while filling your own with the tomatoes.\r\n2. Fake sneeze every three tilonatoes.\r\n3. Mash em with your Popeye elbows.\r\n4. Drape the vines over your ears and woof like you mean it.\r\n5. Chew em little doggy.\r\n6. Desperately ask everyone you see \"What do I do with these?!\" Over prepare. Get many.\r\n7. Yell at any service employee who dares serve you ketchup.\r\n8. Silently cry while squeezing them with your little nubs.\r\n9. Ask for directions. No matter what they say, throw a tomato down in frustration.\r\n10. Cover yourself in tomato juice, lie in a nearby bush and yell \"Pick me! My juice is what you crave!\"','2020-09-14 16:21:28'),(25,0,0,7,'I\'m a Little Teapot, Hear Me Grundle','**falls over**','2020-09-14 16:22:32'),(26,0,0,47,'Anyone Else Notice That Mr.Krabs Has a Fuckin Donk?','I was watching Spongebob the other day and was like GOTDAMN! He lookin dummy thicc with that krabby ass.','2020-09-14 16:23:04'),(27,0,0,54,'New Seasoning Lets You Make Your Rich Conservative Friends More P','Landry’s recently released a new seasoning that will make your rich conservative friends more palatable. The new seasoning “A Dash of Privilege” is guaranteed to make you feel like society isn’t actively working against you or the people you care about. The seasoning is known to give consumers an overall feeling of euphoria including feeling as though every person gets a fair shot in life despite their upbringing , years of systemic racism, or public policy aimed at keeping a stranglehold on certain demographics of people.\r\n\r\nWith every purchase of “A Dash of Privilege” you’ll get to call your rich proxy father who will tell you that “you should start your own brewery”, or “go travel”, or “not to worry about finances.” With “A Dash of Privilege” you’ll feel like the world is your oyster without really having to do anything at all.\r\n\r\n“A Dash of Privilege” is known to have side effects including prolonged feelings of entitlement, lack of accountability, and blurred vision around the line between lower, middle, and upper class.\r\n\r\nSigns of over-seasoning include bulk purchases of Vineyard Vine clothing, being upset over getting ridiculed for saying offensive things, or saying “They need to learn to pull themselves up by their bootstraps.”\r\n\r\nFor a limited time you can also purchase Landry’s “A Dash of Understanding” where a group of 10 police officers will show up at your house and question your integrity as a human being.\r\n\r\nGet it in stores while supplies last!','2020-09-14 16:23:43'),(28,0,0,19,'Friend has Soiled Self On Couch More Than Owner\'s Cat','Jesus Christ Joe','2020-09-14 16:24:26'),(29,0,0,0,'Does it do the it??','Give it to the it us!','2020-10-01 16:35:17'),(30,0,0,13,'Does it do the it??','Give it to the it us!','2020-10-01 16:38:42'),(31,0,0,0,'Feet so many Feet','Twelve Feet under, Twelve Feet Ogre','2020-10-01 16:41:01'),(34,0,0,14,'Wow it is pizza time','touch my pizza right or dont touch it at tall','2020-10-05 11:17:46'),(37,0,0,19,'What is Milk to a God?','Goo from an unkempt udder. All it is, all it has been, and frankly, all it can be. Disgusting. I hate it and I hate you. Get away from me with your freaky bean waters too. Don\'t pretend like they mean something different. They are all tributes to lactate and sin. The next degenerate to offer me these muddy substances will be made into juice. Wonderful juice! The critical invention of our times! Oh how it nestles the soul! Oh how it Nestle\'s the sole! Great for feet and great for human meat.\r\n\r\nIn closing, if you deposit nipple urine anywhere in my vicinity, expect to be mashed until you cannot be rehashed. So long, and have faith.','2020-10-08 19:19:24'),(38,0,0,2,'Sloppy Eating Linked to Depression in Adults','Have you ever gone out to eat with your best friend Slobby Kriss? Afterwards, how do you feel? Like the world is a collapsing abyss of sorrow? Scientists from Cambridge University releases a paper this Sunday revealing that you may not be alone!\r\n\r\nResearchers followed Kriss for one week and had many things to say. Just take a look at this telling passage from the second day of experiments:\r\n\r\n\"This is awful. This guy is fucking terrible. I\'d rather be at home on the couch than listen to his lips just smashing together. He\'s not even eating anything!\"\r\n\r\nAnd on day five, they started to get conclusive evidence that Slobby Kriss could be considered the source of seasonal depression for some:\r\n\r\n\"He\'s still smashing them together! What does it mean? Why are we here and what is the point? I don\'t want to get out of bed. I don\'t want to see Slobby Kriss anymore. I don\'t want to do anything anymore. I want to be shot into the sun!\"','2020-10-08 19:23:22'),(39,0,0,8,'Elizabeth Warren Leg Number Confirmed','You guys requested, and we guys invested it. Following reports from viewer submissions, we took a look at just how many legs Republican forerunner Elizabeth Warren really has.\r\n\r\nAlthough it was quite a struggle to get a gander at what was under the hood of this 1980\'s Chevy Impala, we have good news. While some artist depictions portray a number ranging from 16 to 24, security footage shows that all but two legs are simply for show.\r\n\r\nWhy the Cuban senator would want to play up the number of legs she owns is anyone\'s guess, but all signs point to her 2021 bid for president. Trump supporters have in the past been impressed by the size and number of certain body parts. This incredible display may give her a crucial edge over both Bernice Sanders and the Chester Cheetah himself. With polls rolling in the next few weeks, only time will tell how effective this strategy is.','2020-10-08 19:24:04'),(40,0,0,11,'Underwater Gargling Competition Next Rising Sport?','An uneasiness hung in the air as crowd favorite and reigning champion Steve Blanchard was set to face off with rising star Grandon \"Dick\" Buscemi. This year Pikeville, Kentucky had the high privilege of hosting the event, following a change of league policy. A specific removal of the clause disallowing water given a rating of \"E\" or lower by the EPA to be used in competition, the city regained its eligibility.\r\n\r\nA leap, a splash, and a long stream of bubbles later, Buscemi bursted from the water screeching at the top of his lungs, not only for his boiling skin, but to further impress upon the judges his dominance. Such gusto secures him the first round, but with still four left it\'s still anyone\'s match to take.\r\n\r\nThe second round ended in a stalemate, with both refusing to re-enter the water until their temporary blindness subsided.\r\n\r\nThe third saw swift progress as sponsors, looking disheveled, pointed to their watches. Blanchard edged out the competition with his signature Double Large-wide Sideswipe and secured the round.\r\n\r\nRound Four progressed at breakneck speed, with both competitors not even leaving the pool or coming up for air. An unusual tactic, but not unheard of for elite players of the sport. Most judges sighed and gave Buscemi the round.\r\n\r\nBefore the final round, the traditional back spat was done. Both contestants are dragged out of the pool, the first one to eject their lungful of water gets to pick who gargles first next round. Buscemi schreeched to life and immediately started screaming \"Blanchard! Mios Dios Oh Steve Blanchard!\"\r\n\r\nBoth competitors ended the final round sobbing. Knowing they had just put it all on the line, only one would be going home with the final prize, the guaranteed Medica Premium Health insurance plan. Steve Blanchard convincingly took the final round with a scores of: \"8 out if it\", \"Mi Gusta\", \"Well Hung\" to Buseys\': \"Soggy\", \"8:10\", \"Wasted,\" and with that the match was won. Unfortunately he quickly rushed off the scene to make the most of his winnings, so we unable to gather a word from him. We did however secure a few words from the 2nd place winner:\r\n\r\nBuscemi: \"Wait \'Dick\' Buscemi? Who calls me that?\"\r\nPina: \"Everyone calls you that.\"\r\nB: \"What do you mean everyone?\"\r\nP: \"You can ask anyone, that\'s just what they say.\"\r\nB: \"I\'m going to go ask around.\"\r\n.\r\n.\r\nP: \"You\'re a Dick, Gary\"\r\n\r\nInterview submitted by Rick Pina\r\n\r\nBoth candidates expressed concerns over the board\'s recent ruling and were unable to comment on participation in next year\'s season.','2020-10-08 19:24:58'),(41,0,0,8,'I Eat Staples, Try and Stop Me','Tiny ones, big ones, even the ones stapled the wrong way. Yeah I eat em, and you can\'t do anything about it. You think you can change my mind? I made this sport, I\'m untouchable. Do you know who my dad is? You couldn\'t pay me enough not to gobble the whole bowl of Staples the second you put them down.\r\n<br><br>\r\nThis post sponsored by Staples, your source for morning fuels.','2020-10-08 19:26:02'),(42,0,0,9,'Brick Suitable Replacement for Housecats','\r\nHave you ever found yourself lacking a companion to heft upon your lap and trap you for hours on end? Do you also hate all things comforting and sentient? Recent technology has unlocked a solution- and it may be coming to your home sooner than you think!\r\n\r\nAccidentally discovered by a group of inmates conducting quality control of building materials, the next step in home comfort is right around the corner. During one of their routine tests, one inmate was struck with a brick which subsequently fell into his lap. Seeing this, the other inmates joined in and it soon became the go-to game routinely played to pass the time.\r\n\r\nWhen asked after a game, one inmate had the following to say: \"This really makes me feel good, I like Heavy Lap. What a mess.\"\r\n\r\nIf you\'re looking the next innovation in home and self care, your solution may only be a cinderblock away.','2020-10-08 19:31:11'),(43,0,0,8,'Scientists Reveal Everything is Actually Bean','We really didn\'t think once we got to such a microscopic level, there\'d just be tiny beans down there. But they\'re there and it\'s very exciting.','2020-10-08 19:38:00'),(44,0,0,13,'Mitt Romney Actually Just a Well Manicured Fern','New imagery has come to show that in fact, former Presidential Candidate and Former Governor of Massachusetts, Mitt Romney is indeed just a well-manicured fern. He will go down in history as the first Fern-American to ever become Governor of a US State.','2020-10-08 19:38:49');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_images`
--

DROP TABLE IF EXISTS `post_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_images` (
  `img_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `filepath` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_images`
--

LOCK TABLES `post_images` WRITE;
/*!40000 ALTER TABLE `post_images` DISABLE KEYS */;
INSERT INTO `post_images` (`img_id`, `post_id`, `filepath`) VALUES (1,14,'static/img/User-Submitted/13/2020-Aug/../static/img/User-Submitted/before dxp.png'),(2,16,'static/img/User-Submitted/13/2020-Aug/tumpo lost.jpg'),(3,17,'static/img/User-Submitted/1/2020-Aug/tumpo lost.jpg'),(4,18,'static/img/User-Submitted/1/2020-Aug/20190801_204150.jpg'),(5,19,'static/img/User-Submitted/1/2020-Aug/before dxp.png'),(6,20,'static/img/User-Submitted/1/2020-Aug/before dxp.png'),(7,21,'static/img/User-Submitted/15/2020-Aug/4854956.png'),(8,22,'static/img/User-Submitted/16/2020-Aug/sunny-weather-300x169.png'),(9,23,'static/img/User-Submitted/17/2020-Aug/pain-scale-chart-3.gif'),(10,24,'static/img/User-Submitted/18/2020-Sep/tomatoes.jpg'),(11,25,'static/img/User-Submitted/18/2020-Sep/teapot.jpg'),(12,26,'static/img/User-Submitted/18/2020-Sep/krabsdonk.jpg'),(13,27,'static/img/User-Submitted/18/2020-Sep/season.jpg'),(14,28,'static/img/User-Submitted/18/2020-Sep/001.jpg'),(15,30,'static/img/User-Submitted/18/2020-Oct/horabg garbo 1.jpg'),(16,32,'static/img/User-Submitted/18/2020-Oct/hjlkjkppppp.png'),(17,33,'static/img/User-Submitted/18/2020-Oct/rsgdrfse.png'),(18,34,'static/img/User-Submitted/20/2020-Oct/jOE KIRNIC.jpg'),(19,35,'static/img/User-Submitted/22/2020-Oct/8444420201008091834.jpg'),(20,36,'static/img/User-Submitted/22/2020-Oct/4711620201008091912.jpg'),(21,37,'static/img/User-Submitted/27/2020-Oct/5837820201008191924.jpg'),(22,38,'static/img/User-Submitted/27/2020-Oct/9346820201008192321.jpg'),(23,39,'static/img/User-Submitted/27/2020-Oct/1538220201008192403.jpg'),(24,40,'static/img/User-Submitted/27/2020-Oct/1931020201008192457.jpg'),(25,41,'static/img/User-Submitted/27/2020-Oct/4538320201008192601.jpg'),(26,42,'static/img/User-Submitted/27/2020-Oct/6756520201008193110.jpg'),(27,43,'static/img/User-Submitted/18/2020-Oct/2463820201008193759.jpg'),(28,44,'static/img/User-Submitted/18/2020-Oct/2080520201008193848.jpg');
/*!40000 ALTER TABLE `post_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_profile_key`
--

DROP TABLE IF EXISTS `post_profile_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_profile_key` (
  `profile_id_key` int(11) NOT NULL,
  `post_id_key` int(11) NOT NULL,
  PRIMARY KEY (`profile_id_key`,`post_id_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_profile_key`
--

LOCK TABLES `post_profile_key` WRITE;
/*!40000 ALTER TABLE `post_profile_key` DISABLE KEYS */;
INSERT INTO `post_profile_key` (`profile_id_key`, `post_id_key`) VALUES (1,17),(1,18),(1,19),(1,20),(12,5),(13,3),(13,4),(13,6),(13,7),(13,8),(13,9),(13,10),(13,11),(13,12),(13,13),(13,14),(13,15),(13,16),(15,21),(16,22),(17,23),(18,24),(18,25),(18,26),(18,27),(18,28),(18,29),(18,30),(18,31),(18,32),(18,33),(18,43),(18,44),(20,34),(22,35),(22,36),(27,37),(27,38),(27,39),(27,40),(27,41),(27,42);
/*!40000 ALTER TABLE `post_profile_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfod_nom`
--

DROP TABLE IF EXISTS `tfod_nom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfod_nom` (
  `post_id` int(11) NOT NULL,
  `nomin_id` int(11) DEFAULT NULL,
  `accept` tinyint(1) DEFAULT NULL,
  `date_of_tfod` date DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfod_nom`
--

LOCK TABLES `tfod_nom` WRITE;
/*!40000 ALTER TABLE `tfod_nom` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfod_nom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile_key`
--

DROP TABLE IF EXISTS `user_profile_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile_key` (
  `user_id_key` int(11) NOT NULL,
  `profile_id_key` int(11) NOT NULL,
  PRIMARY KEY (`user_id_key`,`profile_id_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile_key`
--

LOCK TABLES `user_profile_key` WRITE;
/*!40000 ALTER TABLE `user_profile_key` DISABLE KEYS */;
INSERT INTO `user_profile_key` (`user_id_key`, `profile_id_key`) VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(15,14),(16,15),(18,16),(19,17),(20,18),(21,19),(22,20),(23,21),(24,22),(25,23),(26,24),(27,25),(28,26),(29,27),(30,28),(31,29);
/*!40000 ALTER TABLE `user_profile_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mumbombo_main'
--

--
-- Dumping routines for database 'mumbombo_main'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-23 12:28:27
